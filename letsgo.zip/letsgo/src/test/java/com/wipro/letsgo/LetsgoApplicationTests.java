package com.wipro.letsgo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LetsgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
